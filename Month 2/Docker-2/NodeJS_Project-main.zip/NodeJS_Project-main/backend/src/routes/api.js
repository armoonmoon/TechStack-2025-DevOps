const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { getRedisClient } = require('../config/redis');

// Get all users (with Redis caching)
router.get('/users', async (req, res) => {
  try {
    const redisClient = getRedisClient();
    const cacheKey = 'users:all';
    
    // Check cache first
    const cachedUsers = await redisClient.get(cacheKey);
    if (cachedUsers) {
      return res.json({ 
        source: 'cache',
        data: JSON.parse(cachedUsers) 
      });
    }
    
    // Fetch from database
    const users = await User.find();
    
    // Store in cache (expire in 1 hour)
    await redisClient.setEx(cacheKey, 3600, JSON.stringify(users));
    
    res.json({ 
      source: 'database',
      data: users 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create a new user
router.post('/users', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    
    // Invalidate cache
    const redisClient = getRedisClient();
    await redisClient.del('users:all');
    
    res.status(201).json(user);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get user by ID
router.get('/users/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Cache operations
router.post('/cache/:key', async (req, res) => {
  try {
    const redisClient = getRedisClient();
    const { key } = req.params;
    const { value, expiry } = req.body;
    
    if (expiry) {
      await redisClient.setEx(key, expiry, JSON.stringify(value));
    } else {
      await redisClient.set(key, JSON.stringify(value));
    }
    
    res.json({ message: 'Cache set successfully', key });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/cache/:key', async (req, res) => {
  try {
    const redisClient = getRedisClient();
    const value = await redisClient.get(req.params.key);
    
    if (!value) {
      return res.status(404).json({ error: 'Key not found in cache' });
    }
    
    res.json({ key: req.params.key, value: JSON.parse(value) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;