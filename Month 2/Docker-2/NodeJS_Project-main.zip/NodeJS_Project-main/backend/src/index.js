const express = require('express');
const cors = require('cors');
const connectDB = require('./config/database');
const connectRedis = require('./config/redis');
const apiRoutes = require('./routes/api');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date() });
});

// API Routes
app.use('/api', apiRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.json({ 
    message: 'Welcome to Node.js Dockerized App',
    services: ['MongoDB', 'Redis', 'Nginx'],
    endpoints: {
      health: '/health',
      users: '/api/users',
      cache: '/api/cache/:key'
    }
  });
});

// Initialize connections and start server
async function startServer() {
  try {
    await connectDB();
    await connectRedis();
    
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📊 Environment: ${process.env.NODE_ENV}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();