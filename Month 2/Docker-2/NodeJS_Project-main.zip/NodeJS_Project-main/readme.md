# Node.js Dockerized Application

A professional Node.js application demonstrating microservices architecture with Docker, featuring MongoDB, Redis, and Nginx.

## Architecture

- **Backend**: Node.js + Express REST API
- **Database**: MongoDB for persistent data storage
- **Cache**: Redis for caching and session management
- **Reverse Proxy**: Nginx for load balancing and request routing



## API Endpoints

### Health Check
```bash
GET /health
```

### Users
```bash
# Get all users (with Redis caching)
GET /api/users

# Create a new user
POST /api/users
Content-Type: application/json
{
  "name": "John Doe",
  "email": "john@example.com",
  "age": 30
}

# Get user by ID
GET /api/users/:id
```

### Cache Operations
```bash
# Set cache
POST /api/cache/:key
Content-Type: application/json
{
  "value": "your data",
  "expiry": 3600
}

# Get cache
GET /api/cache/:key
```

## Testing the Application

```bash
# Create a user
curl -X POST http://localhost/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@example.com","age":25}'

# Get all users (first call - from database)
curl http://localhost/api/users

# Get all users again (second call - from cache)
curl http://localhost/api/users

# Test cache
curl -X POST http://localhost/api/cache/mykey \
  -H "Content-Type: application/json" \
  -d '{"value":"Hello World","expiry":60}'

curl http://localhost/api/cache/mykey